# DWNO Return to the Title Screen Mod
This mod replaces the "Quit Game" function in the Digivice with a function to return to the Title Screen instead.
In addition it also skips the waiting time at the Splash Screen and removes the Logos and Opening Movie if Savedata in any of the Slots exists.
If no Savedata is found it will play the Logos and Intro. Given the nature of how the title scene is structured, at present there is no way to prevent it being loaded at just one point.

# Installation
1. Install BepInEx (Tutorial by Yasha-jin)
2. Download the latest release from the Releases Tab
3. Copy the BackToTheTitleScreen.dll into the plugins folder of BepinEx
4. Start the game and enjoy :)

# Contact
Discord: Romsstar#8098, or in either the Digimon Modding Community or Digimon Discord Community